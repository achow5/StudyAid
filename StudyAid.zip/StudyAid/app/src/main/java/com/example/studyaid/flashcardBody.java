package com.example.studyaid;

public class flashcardBody {

    private long mId;
    private String mQuestion;
    private String mAnswer;
    private String mTopic;

    public String getQuestion() {
        return mQuestion;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getId() {
        return mId;
    }

    public void setQuestion(String question) {
        this.mQuestion = question;
    }

    public String getAnswer() {
        return mAnswer;
    }

    public void setAnswer(String answer) {
        this.mAnswer = answer;
    }

    public String getTopic() {
        return mTopic;
    }

    public void setTopic(String topic) {
        this.mTopic = topic;
    }

}
