package com.example.studyaid;

public class Topic {

    private String mText;

    public Topic() {

    }

    public Topic(String text) {
        mText = text;
    }

    public String getText() {
        return mText;
    }

    public void setText(String text) {
        mText = text;
    }
}
